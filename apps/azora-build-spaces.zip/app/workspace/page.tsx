"use client"

import { redirect } from "next/navigation"

export default function WorkspacePage() {
  redirect("/code-chamber")
}
