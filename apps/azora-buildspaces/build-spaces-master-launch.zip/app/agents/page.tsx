import { redirect } from "next/navigation"

export default function AgentsRedirect() {
  redirect("/features/agents")
}
