import { Navbar } from "@/components/features/navbar"
import { Footer } from "@/components/features/footer"
import { AetherBackground } from "@/components/ui/aether-background"
import { Button } from "@/components/ui/button"
import { AfricanAgentAvatar } from "@/components/ui/african-agent-avatar"
import Link from "next/link"
import { BookOpen, Code2, Terminal, Rocket, Brain, ArrowRight, Search } from "lucide-react"

const quickLinks = [
  {
    icon: Rocket,
    title: "Getting Started",
    desc: "Set up your first project in 5 minutes",
    href: "/docs/getting-started",
  },
  { icon: Code2, title: "Code Chamber", desc: "Master the cloud IDE", href: "/docs/code-chamber" },
  { icon: Terminal, title: "CLI Reference", desc: "Command line tools", href: "/docs/cli" },
  { icon: Brain, title: "AI Agents", desc: "Work with Elara and team", href: "/docs/agents" },
]

const sections = [
  {
    title: "Core Concepts",
    items: [
      "The 7 Rooms Architecture",
      "Constitutional AI",
      "Agent Orchestration",
      "Project Structure",
      "Environment Setup",
    ],
  },
  {
    title: "Rooms",
    items: ["Code Chamber", "Spec Chamber", "Design Studio", "AI Studio", "Command Desk", "Maker Lab", "Collab Pod"],
  },
  {
    title: "AI Agents",
    items: [
      "Elara (Orchestrator)",
      "Sankofa (Code)",
      "Themba (Systems)",
      "Jabari (Security)",
      "Nia (Data)",
      "Imani (Design)",
    ],
  },
  {
    title: "Integrations",
    items: ["GitHub", "Vercel", "Supabase", "Stripe", "Figma", "Slack"],
  },
]

export default function DocsPage() {
  return (
    <div className="min-h-screen bg-[#0d1117] text-white">
      <Navbar />

      <main>
        {/* Hero */}
        <section className="relative py-16 overflow-hidden border-b border-white/10">
          <AetherBackground intensity="low" showParticles={false} />

          <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex items-center gap-3 mb-6">
              <BookOpen className="h-8 w-8 text-emerald-400" />
              <h1 className="text-3xl font-bold">Documentation</h1>
            </div>

            <p className="text-gray-400 max-w-2xl mb-8">
              Everything you need to build with BuildSpaces. Guides, API references, and best practices.
            </p>

            {/* Search */}
            <div className="max-w-xl">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-500" />
                <input
                  type="text"
                  placeholder="Search documentation..."
                  className="w-full bg-white/5 border border-white/10 rounded-xl pl-12 pr-4 py-3 text-white placeholder-gray-500 focus:border-emerald-500/50 focus:outline-none"
                />
                <kbd className="absolute right-4 top-1/2 -translate-y-1/2 hidden sm:inline-flex h-6 items-center gap-1 rounded border border-white/10 bg-white/5 px-2 font-mono text-xs text-gray-400">
                  ⌘K
                </kbd>
              </div>
            </div>
          </div>
        </section>

        {/* Quick Links */}
        <section className="py-12 px-4 sm:px-6 lg:px-8 border-b border-white/10">
          <div className="mx-auto max-w-7xl">
            <div className="grid md:grid-cols-4 gap-4">
              {quickLinks.map((link) => (
                <Link
                  key={link.title}
                  href={link.href}
                  className="group flex items-start gap-4 rounded-xl bg-white/5 border border-white/10 p-4 hover:border-emerald-500/50 transition-colors"
                >
                  <link.icon className="h-6 w-6 text-emerald-400 mt-0.5" />
                  <div>
                    <h3 className="font-medium group-hover:text-emerald-400 transition-colors">{link.title}</h3>
                    <p className="text-sm text-gray-400">{link.desc}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* Documentation Sections */}
        <section className="py-12 px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-7xl">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {sections.map((section) => (
                <div key={section.title}>
                  <h3 className="font-semibold mb-4 text-white">{section.title}</h3>
                  <ul className="space-y-2">
                    {section.items.map((item) => (
                      <li key={item}>
                        <Link href="#" className="text-sm text-gray-400 hover:text-emerald-400 transition-colors">
                          {item}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Ask AI Section */}
        <section className="py-12 px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-4xl">
            <div className="rounded-2xl bg-gradient-to-br from-emerald-500/10 to-cyan-500/10 border border-emerald-500/20 p-8">
              <div className="flex items-start gap-4">
                <AfricanAgentAvatar agent="elara" size="lg" />
                <div className="flex-1">
                  <h3 className="text-xl font-semibold mb-2">Need help? Ask Elara</h3>
                  <p className="text-gray-400 mb-4">
                    {"Can't"} find what {"you're"} looking for? Our AI assistant can help you navigate the docs and
                    answer questions.
                  </p>
                  <div className="flex items-center gap-4">
                    <input
                      type="text"
                      placeholder="Ask a question about BuildSpaces..."
                      className="flex-1 bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:border-emerald-500/50 focus:outline-none"
                    />
                    <Button className="bg-emerald-500 hover:bg-emerald-600">
                      Ask <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
